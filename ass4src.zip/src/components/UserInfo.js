import React from "react";

// Create a function component and set props as the argument
function UserInfo() {
  return (
    <div>
      <img src="https://i.imgur.com/OH7dtc0.png" alt="" />
      <p>Ironhacker</p>
    </div>
  );
}

// export the component
export default UserInfo;
